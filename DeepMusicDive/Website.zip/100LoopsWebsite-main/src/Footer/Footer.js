import React from 'react';

function Footer() {
    return (
        <div>
            <footer className="bottom">
                <div className="center">
                    All rights reserved &copy; Cameron Stanley
                </div>
            </footer>
        </div>
    );
}

export default Footer;
